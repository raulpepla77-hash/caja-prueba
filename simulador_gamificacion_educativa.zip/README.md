# SimuGam Lab - Laboratorio de Dinámicas de Gamificación

Simulador interactivo autónomo en HTML5, CSS (Tailwind) y JavaScript nativo para modelar el impacto pedagógico de mecánicas de gamificación en aulas virtuales (como Moodle).

## 🚀 Cómo ejecutarlo
1. Descomprime este archivo `.zip`.
2. Haz doble clic en `index.html` para abrirlo directamente en cualquier navegador web moderno (Chrome, Edge, Firefox, Safari) en PC o móvil. No requiere servidor local ni dependencias externas complejas.

## 🧠 Fundamentos Teóricos Incorporados
- **Teoría de la Autodeterminación (SDT - Ryan & Deci, 2000):** Visualización vectorial en radar de las tres necesidades psicológicas básicas (Autonomía, Competencia y Relación).
- **Canal de Flujo (Csíkszentmihályi, 1990):** Calibración de la dificultad cognitiva vs. habilidades del estudiante para prevenir ansiedad o aburrimiento.
- **Efecto de Sobrejustificación (Overjustification Effect):** Detección de desplazamientos de motivación intrínseca provocados por la hiper-recompensa extrínseca.
- **Métricas de Aprendizaje:** Cálculo en tiempo real de retención proyectada, sobrecarga cognitiva y toxicidad por competencia abierta en tablas de líderes.
- **Auditoría Técnica:** Exportación de informes diagnósticos estructurados con recomendaciones para plugins y ajustes nativos de Moodle.
